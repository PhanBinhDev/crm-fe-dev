import { Edit, useForm, RefreshButton } from '@refinedev/antd';
import { Card } from 'antd';
import { UserForm } from '@/pages/users/form/components/UserForm';
import { IUser, User } from '@/common/types';
import { useParams } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

export const UserEdit = () => {
  const { formProps, saveButtonProps } = useForm<IUser>();
  const { user: identity } = useAuth();
  const { id } = useParams();

  const handleFinish = async (values: any) => {
    if (formProps.onFinish) {
      formProps.onFinish(values);
    }
  };

  const isSelfEdit = identity?.id === id;

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto' }}>
      <Edit
        saveButtonProps={{
          ...saveButtonProps,
          children: 'Lưu',
        }}
        title="Chỉnh sửa người dùng"
        breadcrumb={false}
        headerButtons={({ refreshButtonProps }) => (
          <>
            <RefreshButton {...refreshButtonProps}>Làm mới</RefreshButton>
          </>
        )}
      >
        <Card styles={{ body: { padding: '32px 24px' } }}>
          <UserForm
            onFinish={handleFinish}
            initialValues={formProps.initialValues as IUser}
            isEdit={true}
            isSelfEdit={isSelfEdit}
          />
        </Card>
      </Edit>
    </div>
  );
};
